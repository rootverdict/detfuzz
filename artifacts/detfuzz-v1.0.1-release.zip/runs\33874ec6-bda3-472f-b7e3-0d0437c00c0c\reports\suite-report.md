# DetFuzz Evidence Report

Suite ID: `33874ec6-bda3-472f-b7e3-0d0437c00c0c`
Suite status: `COMPLETED`
Generated UTC: `2026-08-13T09:24:00.739700+00:00`
Case count: `8`

## Classification Summary

- `DETECTED`: 6
- `INVALID_MUTANT`: 1
- `VALID_BYPASS`: 1

## Cases

- `B0`: `DETECTED`
- `M1`: `VALID_BYPASS`
- `M2`: `DETECTED`
- `M3`: `DETECTED`
- `M4`: `DETECTED`
- `M5`: `DETECTED`
- `NC1`: `INVALID_MUTANT`
- `B1`: `DETECTED`

## Evidence Manifest

- `B0/case-record.json` (2414 bytes, sha256 `6521ffd7d1d3e47bc532299def8f99109292b3849b0bf1da1a1e8c5979ec8836`)
- `B0/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `B0/effect.json` (133 bytes, sha256 `88553bc5c401a337952fbd89a88e5c16ff3867d4a52bbbba9f20856f1ceef85b`)
- `B0/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `B0/execution.json` (2224 bytes, sha256 `46fbef6a0ba5a8409fe7fc09947937e5a89742c2e1b17d9585e8721dcca795aa`)
- `B0/marker-validation.json` (245 bytes, sha256 `70128380e51dea0bf1e6f0dc584f3c22f2eb878d297f293f1215a4c3dc477f5a`)
- `B0/matched-sysmon-event.xml` (3877 bytes, sha256 `22f5aaa307dc04e5359da638caf636eab1251917b0af300ce00d46b0d1dcad60`)
- `B0/telemetry-validation.json` (7180 bytes, sha256 `0fd4f0e632e99e0519d50ba4ac764119f87cc8ab0d5270ea3be7d23f5af82921`)
- `B1/case-record.json` (2430 bytes, sha256 `9c0637ac3d9aa65f23ffbc837661a265f980c582b03e4485c492805d23da6d6b`)
- `B1/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `B1/effect.json` (133 bytes, sha256 `63cfaf7ea4b08d002ca65a281077f4cd8d0fe9b199e241d281002bb94f4c48f7`)
- `B1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `B1/execution.json` (2224 bytes, sha256 `96abca9cda30991536df046ae8816d497688f8e428b6ed54804e171eab22a7c0`)
- `B1/marker-validation.json` (245 bytes, sha256 `da7c3fa3e1cea1239d85fa141e1473207cd908d15fbf407e081968e5cbc06bb1`)
- `B1/matched-sysmon-event.xml` (3877 bytes, sha256 `e12ac75b49e5d85abe0d9333702db88e0a7dcfb3bb33cbf02ac8bda071161137`)
- `B1/telemetry-validation.json` (7180 bytes, sha256 `369e5254a1a969623ba7e6accf3d383a48b2e4a56a18474fefba1320df785853`)
- `M1/case-record.json` (2439 bytes, sha256 `c1da61193cac7533ab8def14738beeaf3d46ca7adf76557e0fef0583379f8611`)
- `M1/detection-result.json` (260 bytes, sha256 `8eb64610480766602158580239cc2c035c40ad7d004210f4bc7b60affc7685b6`)
- `M1/effect.json` (133 bytes, sha256 `f2578d1a36ed9002af1217eae55f93dd9c441ce374c302d46e848cb792099c7b`)
- `M1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M1/execution.json` (2213 bytes, sha256 `1813f7dd9793bdf48fbf5765d16669a7c4bdeeeaffe51583180df9dc91fd6e43`)
- `M1/marker-validation.json` (245 bytes, sha256 `0057863abecbb21e10470361506f1a384fdba8126ba18854d753502535020713`)
- `M1/matched-sysmon-event.xml` (3866 bytes, sha256 `2b31b2310ae310e8d6d6cd8223fb979be2aa9b103472fa657674e7ca6ccb7d86`)
- `M1/telemetry-validation.json` (7158 bytes, sha256 `7e348513add1e42b7f0c99699b82b1ec652fc87a8550bc0753d3a7b122d3fa8a`)
- `M2/case-record.json` (2421 bytes, sha256 `416fd8f73d550aa43d0c7ee1299b264134a32bae942696e10ab42a752fec2712`)
- `M2/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M2/effect.json` (133 bytes, sha256 `b09944dd07554e4bc620eca7cfcea11f8e8798ed2443391391de58cb5426ced0`)
- `M2/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M2/execution.json` (2225 bytes, sha256 `8eb92d0b7f40e3ecfb95f6586e0db75cba0d31f54e73fc1c48a7a72d43c119e6`)
- `M2/marker-validation.json` (245 bytes, sha256 `564e193cdaa2e47b095bc0e673424a8bbd2bc984312a76c0ef2b635269bcfd8a`)
- `M2/matched-sysmon-event.xml` (3878 bytes, sha256 `fbc937012a19bf2c84364e318b3e52e769496cd98ade46d5dd0f54446d0fdd4f`)
- `M2/telemetry-validation.json` (7182 bytes, sha256 `77de90ed4233ab2593acac15364d13a06faa3cb65901ace6748b74df82689c21`)
- `M3/case-record.json` (2428 bytes, sha256 `3a0858e069b3d1b8c9972beab0b1c1bbdc9b59796358b11aa144c26a99161951`)
- `M3/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M3/effect.json` (133 bytes, sha256 `b0d70c93a241f63b22e4cb37f2cd4725ed57a481edd4576ee767c434dd5a4b0e`)
- `M3/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M3/execution.json` (2236 bytes, sha256 `dea0d8c64849ec3a53413d140dede59cbbb2e3cf0fbe09810ecb379329cd052c`)
- `M3/marker-validation.json` (245 bytes, sha256 `7a81b98cf7065bbf606513a9d9605975b3b62ddd4439734c2d5f6b1e24a4ec1b`)
- `M3/matched-sysmon-event.xml` (3889 bytes, sha256 `408977332b3b2ce54d9fac6c158c0e31e90d45cbc01d07bb104eb9f4f02eb6b2`)
- `M3/telemetry-validation.json` (7204 bytes, sha256 `a318db21a3b255d37a08fe18a9cb94542a3ee9f8958123b605c0cba432cd61b7`)
- `M4/case-record.json` (2418 bytes, sha256 `578e9d0b6a5c9dfb8f4e0b500288d3fb0624079a1c69f62afc439ed3e1f8d5d8`)
- `M4/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M4/effect.json` (133 bytes, sha256 `ed1e4df4841c222f940dafbfae7dcbfde1020aa318185722cbe74188a904e16b`)
- `M4/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M4/execution.json` (2229 bytes, sha256 `ba23624b39fc375c9a3e38b47d691606777d7aed550605e6a34632c2b267fd33`)
- `M4/marker-validation.json` (245 bytes, sha256 `fefcb9cbc142cc5ecf0f376f675ba6132e461788a8b47420347ba9966b7f2de7`)
- `M4/matched-sysmon-event.xml` (3880 bytes, sha256 `02d0f0eaa0c3da9455a255f4b363b0adf2f8feaa571f62842b4fdea1e8b21bc5`)
- `M4/telemetry-validation.json` (7190 bytes, sha256 `41196de17aca3264c5793ccd09fba4060b1894b4b3a393e69393bb741952d182`)
- `M5/case-record.json` (2422 bytes, sha256 `a3b6c001a1a163ff429634689ac873e261fc02d37ea0092694b5e0464139a09b`)
- `M5/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M5/effect.json` (133 bytes, sha256 `b0296137da1ee2b238ad633227904d5a2e1143b3deafa57f482550e26b084bbe`)
- `M5/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M5/execution.json` (2225 bytes, sha256 `03e474460e4ccc541b441a5d9c2fa6936711c71bd31e5cf4c1cc28eec234afa1`)
- `M5/marker-validation.json` (245 bytes, sha256 `e86f0ddde3ac78243b71c20576d06e5bbd0b62bdd3357ac51054cdc415a5f6fe`)
- `M5/matched-sysmon-event.xml` (3878 bytes, sha256 `9ffb23518badb66045b5bcf7c43d8c20aaa50c96b8dfa378bc5af9f863d06c0f`)
- `M5/telemetry-validation.json` (7182 bytes, sha256 `4c1ed070b848bfa5d3ed223a22de614e7f2b501600eebfcf448c660145cb5d86`)
- `NC1/case-record.json` (1202 bytes, sha256 `599acad2b7ab6812db8e081c5ab161116a11ff860a11b8c21654bdda12085f87`)
- `NC1/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `NC1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `NC1/execution.json` (5499 bytes, sha256 `60ed3b4efeeae777ff2e9a481c3c284945221ac2f51f8ab30540d6ccff5795e6`)
- `NC1/marker-validation.json` (101 bytes, sha256 `6218f1fd97772912172cdea0c3165f899645563e7f45c2f572e14983a5aa2650`)
- `NC1/matched-sysmon-event.xml` (2621 bytes, sha256 `ed49cf5a030ce9fb409787b5c391089bd90938b3448957b13cf379cec1d44b64`)
- `NC1/telemetry-validation.json` (4668 bytes, sha256 `06f72d8e7a2e5683adbe7812d05c6034cf4e2e7b6c519845adf60fc9c02f7200`)

## Notes

- Generated by detfuzz run-suite.
- Candidate bypasses are finalized only after B1 succeeds.
